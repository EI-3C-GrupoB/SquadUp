package com.example.squadup.features.events.manageevent

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.squadup.core.app.AppViewModel

@Composable
fun ManageEventRoute(
    eventId: String,
    selectedRoute: String,
    onNavItemClick: (String) -> Unit,
    onBackClick: () -> Unit,
    onFormTeamsClick: () -> Unit,
    onEditEventClick: () -> Unit,
    onCancelEventClick: () -> Unit = {},
    onManageLiveClick: (String) -> Unit = {},
    onCreateGameClick: () -> Unit,
    onEditGameClick: (String) -> Unit,
    appViewModel: AppViewModel,
    viewModel: ManageEventViewModel = viewModel()
) {
    LaunchedEffect(eventId) {
        viewModel.loadEvent(eventId)
    }

    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val appUiState by appViewModel.uiState.collectAsStateWithLifecycle()

    ManageEventScreen(
        uiState = uiState,
        selectedRoute = selectedRoute,
        onNavItemClick = onNavItemClick,
        onBackClick = onBackClick,
        onTabChange = viewModel::onTabChange,
        onTeamSearchQueryChange = viewModel::onTeamSearchQueryChange,
        onFreeAgentSearchQueryChange = viewModel::onFreeAgentSearchQueryChange,
        onLoadMoreTeams = viewModel::onLoadMoreTeams,
        onLoadMoreFreeAgents = viewModel::onLoadMoreFreeAgents,
        onGameSearchQueryChange = viewModel::onGameSearchQueryChange,
        onTeamExpand = viewModel::onTeamExpand,
        onPlayerRemove = viewModel::onPlayerRemove,
        onAddPlayerClick = {},
        onEditTeamClick = {},
        onDeleteTeamClick = {},
        onEditGameClick = viewModel::onShowEditGameDialog,
        onCreateGameClick = viewModel::onShowCreateGameDialog,
        onDismissCreateGameDialog = viewModel::onDismissCreateGameDialog,
        onCreateGameHomeTeamChange = viewModel::onCreateGameHomeTeamChange,
        onCreateGameAwayTeamChange = viewModel::onCreateGameAwayTeamChange,
        onCreateGameDateChange = viewModel::onCreateGameDateChange,
        onCreateGameTimeChange = viewModel::onCreateGameTimeChange,
        onCreateGameVenueChange = viewModel::onCreateGameVenueChange,
        onConfirmCreateGame = viewModel::onConfirmCreateGame,
        onDismissEditGameDialog = viewModel::onDismissEditGameDialog,
        onEditGameHomeTeamChange = viewModel::onEditGameHomeTeamChange,
        onEditGameAwayTeamChange = viewModel::onEditGameAwayTeamChange,
        onEditGameDateChange = viewModel::onEditGameDateChange,
        onEditGameTimeChange = viewModel::onEditGameTimeChange,
        onEditGameVenueChange = viewModel::onEditGameVenueChange,
        onConfirmEditGame = viewModel::onConfirmEditGame,
        onFormTeamsClick = onFormTeamsClick,
        onEditEventClick = onEditEventClick,
        onStatusActionClick = viewModel::onStatusAction,
        onCancelEventClick = viewModel::onCancelEvent,
        onAcceptIndividualRegistration = viewModel::acceptIndividualRegistration,
        onRejectIndividualRegistration = viewModel::rejectIndividualRegistration,
        onAcceptTeamRegistration = viewModel::acceptTeamRegistration,
        onRejectTeamRegistration = viewModel::rejectTeamRegistration,
        onManageLiveClick = onManageLiveClick,
        onViewAllRegistrationsClick = {},
        isAdmin = appUiState.isAdmin,
        isAdminView = appUiState.isAdminView,
        onAdminViewChange = { appViewModel.onAdminViewChange(it) },
        selectedLanguage = appUiState.selectedLanguage,
        isDarkMode = appUiState.isDarkMode,
        onLanguageChange = { appViewModel.onLanguageChange(it) },
        onDarkModeChange = { appViewModel.onDarkModeChange(it) }
    )
}
